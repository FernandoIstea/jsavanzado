// declarar variables, constantes, y enlaces al DOM HTML
const carrito = []
const categoriasContainer = document.querySelector("#categoriasContainer")
const cardContainer = document.querySelector("div.card-container")
const inputSearch = document.querySelector("input#inputSearch")
const buttonCarrito = document.querySelector("div.shoping-cart")
const divArrow = document.querySelector("div#arrow-up")

function crearCardHTML(producto) {

    return `<div class="card">
                <div class="product-image">${producto.imagen}</div>
                <div class="product-name">${producto.nombre}</div>
                <div class="product-price">$ ${producto.precio.toLocaleString()}</div>
                <div class="buy-button">
                    <button id="buttonComprar" data-codigo="${producto.id}" >COMPRAR</button>
                </div>
            </div>`
}

function crearCardErrorHTML() {
    return `<div class="card-error">
                <div class="error-title">
                    <h3>Se ha producido un error inesperado.</h3>
                    <div class="emoji-error">🔌</div>
                    <h4>Por favor, intenta acceder nuevamente en unos instantes.</h4>
                    <p>No estamos pudiendo cargar el listado de productos para tu compra.</p>
                    <div class="emoji-error">
                        <span>🥑</span>
                        <span>🍉</span>
                        <span>🍋‍🟩</span>
                        <span>🍏</span>
                    </div>
                </div>
            </div>`
}

function crearCategoria(cate) {
    const categoriaSpan = document.createElement("span") 
    categoriaSpan.textContent = cate
    categoriaSpan.id = "categoriaId"
    categoriaSpan.className = "category"

    return categoriaSpan
}

function cargarCategorias() {    
    for (let categoria of categorias) {
        let spanHTML = crearCategoria(categoria)
        categoriasContainer.appendChild(spanHTML)
    }
}

function activarFiltrosPorCategoria() {
    const spanCategorias = document.querySelectorAll("span#categoriaId")

    spanCategorias.forEach((categoria)=> {
        categoria.addEventListener("click", ()=> {
            if (categoria.textContent === "Todos") {
                cargarProductos(productos)
            } else {
                const productosFiltrados = productos.filter((prod)=> prod.categoria === categoria.textContent)
                cargarProductos(productosFiltrados)
            }
            activarEventosClickBtnComprar()
        }) 
    })
}

function activarEventosClickBtnComprar() {
    const botonesComprar = document.querySelectorAll("button#buttonComprar")

    botonesComprar.forEach((botonComprar)=> {
        botonComprar.addEventListener("click", ()=> {
            const productoSeleccionado = productos.find((prod)=> prod.id === botonComprar.dataset.codigo )
            carrito.push(productoSeleccionado)
            console.clear()
            console.table(carrito)
        })
    })
}

function cargarProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        cardContainer.innerHTML = ""
        arrayProductos.forEach((producto)=> cardContainer.innerHTML += crearCardHTML(producto) )
    } else {
        cardContainer.innerHTML = crearCardErrorHTML()
    }
}


function armarContenido() {
    cargarCategorias()
    cargarProductos(productos)
    activarEventosClickBtnComprar()
    activarFiltrosPorCategoria()
}

// Función principal (una sola función)
armarContenido()


// EVENTOS JS sobre elementos HTML

inputSearch.addEventListener("keypress", (event)=> {

    const condicionOk = event.key === "Enter" && inputSearch.value.trim() !== "" && inputSearch.value.length >= 3

    if (condicionOk) {
        let parametro = inputSearch.value.trim().toLowerCase() // normalizamos el dato

        const productosFiltrados = productos.filter((prod)=> prod.nombre.toLowerCase().includes(parametro) )

        if (productosFiltrados.length > 0) {
            cargarProductos(productosFiltrados)
            activarEventosClickBtnComprar()
        } else {
            console.warn("No se encontraron coincidencias.")
        }
    }
})

buttonCarrito.addEventListener("mousemove", ()=> {
    if (carrito.length === 0) {
        buttonCarrito.title = "Agrega productos al carrito"
    } else {
        buttonCarrito.title = carrito.length + " producto(s) en carrito"
    }
})

buttonCarrito.addEventListener("click", (event)=> {
    console.log(event)
    if (navigator.onLine === false) {
        return 
    }

    if (carrito.length > 0) {
        location.href = "checkout.html"
    } else {
        alert("⚠️ Agrega productos al carrito.")
    }
}) 

window.addEventListener("offline", ()=> {
    console.warn("Has perdido conexión a Internet.")
})

window.addEventListener("online", ()=> {
    console.log("Ha vuelto la conectividad a Internet.")
})

divArrow.addEventListener("click", ()=> {
    window.scrollTo({top: 0, behavior: 'smooth'})
})

document.addEventListener("scroll", ()=> {
    if (window.scrollY > 300) {
        divArrow.classList.remove("hide-arrow")
    } else {
        divArrow.classList.add("hide-arrow")
    }
})