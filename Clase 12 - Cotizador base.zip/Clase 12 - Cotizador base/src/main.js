const valorM2 = 417

const arrayUbicaciones = []
const arrayPropiedades = []

const selectUbicacion = document.querySelector("select#ubicacion")
const selectPropiedad = document.querySelector("select#tipoPropiedad")
const inputM2 = document.querySelector("input#superficie")
const btnCotizar = document.querySelector("button#Cotizar")
 
// endpoints de app backend
const URLUbicaciones = ""
const URLpropiedades = ""
