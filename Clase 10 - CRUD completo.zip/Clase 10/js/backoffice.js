const URLproductos = "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos"
let operacion = "" // (n = nuevo - e = editar)

const opciones = {
    method: '',
    headers: { 'content-type': 'application/json'},
    body: ''
}

const dialog = document.querySelector("dialog")

const btnNuevo = document.querySelector("button.btn-nuevo")
const btnGuardar = document.querySelector("button#btnGuardar")
const btnEliminar = document.querySelector("button#btnEliminar")

const inputId = document.querySelector("input#inputId")
const inputImagen = document.querySelector("input#inputImagen")
const inputNombre = document.querySelector("input#inputNombre")
const inputPrecio = document.querySelector("input#inputPrecio")
const selectCategoria = document.querySelector("select#selectCategoria")

const tableBody = document.querySelector("table tbody#tableBody")

const productos = []

function armarFilaHTML(producto) {
    return `<tr data-filaCodigo="${producto.id}">
                <td id="pImagen">${producto.imagen}</td>
                <td id="nombre">${producto.nombre}</td>
                <td id="price">$ ${producto.precio.toLocaleString()}</td>
                <td id="categoría">${producto.categoria}</td>
                <td id="delButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para eliminar">
                    ⛔️
                </td>
                <td id="editButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para Modificar">
                    ✍️
                </td>
            </tr>`
}

function mostrarMensaje(mensaje, estilo, timer) {
    ToastIt.now({
        message: mensaje,
        style: estilo,
        close: false,
        timer: timer,
        position: ''
    })
}

function obtenerProductos() {
    fetch(URLproductos)
    .then((response)=> response.json() )
    .then((data)=> {
        productos.length = 0
        productos.push(...data)
    })
    .then(()=> {
        cargarProductos()
        activarClicEditarProducto()
        activarClicEliminarProducto()
    } )
    .catch((err)=> {
        let mensaje = `Se ha producido un error: ${err.message}`
        mostrarMensaje(mensaje, 'error', 4500)
    } )
}

function activarClicEditarProducto() {
    const botonesEditar = document.querySelectorAll("td#editButton")

    if (botonesEditar.length > 0) {
        botonesEditar.forEach((botonEditar)=> {
            botonEditar.addEventListener("click", ()=> {
                console.log(botonEditar.dataset.codigo)
                let productoAeditar = productos.find((prod)=> prod.id === botonEditar.dataset.codigo )
                inputId.value = productoAeditar.id 
                inputImagen.value = productoAeditar.imagen 
                inputNombre.value = productoAeditar.nombre 
                inputPrecio.value = productoAeditar.precio
                selectCategoria.value = productoAeditar.categoria
                btnEliminar.setAttribute('hidden', 'true')
                btnGuardar.removeAttribute('hidden')
                operacion = 'e'
                dialog.showModal()
            })
        })
    }
}

function activarClicEliminarProducto() {
    const botonesEliminar = document.querySelectorAll("td#delButton")

    if (botonesEliminar.length > 0) {
        botonesEliminar.forEach((botonEliminar)=> {
            botonEliminar.addEventListener("click", ()=> {

                let productoAquitar = productos.find((prod)=> prod.id === botonEliminar.dataset.codigo )
                inputId.value = productoAquitar.id 
                inputImagen.value = productoAquitar.imagen 
                inputNombre.value = productoAquitar.nombre 
                inputPrecio.value = productoAquitar.precio
                selectCategoria.value = productoAquitar.categoria
                btnEliminar.removeAttribute('hidden')
                btnGuardar.setAttribute('hidden', 'true')
                dialog.showModal()

            })
        })
    }
}

function cargarProductos() {
    if (productos.length > 0) {
        let filasProductos = ""
        productos.forEach((prod)=> {
            filasProductos += armarFilaHTML(prod)
        })
        tableBody.innerHTML = filasProductos
    }
}

// Función principal
obtenerProductos()

// EVENTOS
btnNuevo.addEventListener("click", ()=> {
    operacion = 'n'
    btnEliminar.setAttribute('hidden', 'true')
    btnGuardar.removeAttribute('hidden')
    inputId.value = ""
    inputImagen.value = ""   
    inputNombre.value = ""   
    inputPrecio.value = ""   
    selectCategoria.value = selectCategoria[0].value
    dialog.showModal()
})

btnGuardar.addEventListener("click", ()=> {
    if (operacion === 'n') {
        // nuevo producto
        // validar campos con contenido (id, nombre, imagen, precio, cate)
        let nuevoProducto = {
            imagen: inputImagen.value,
            nombre: inputNombre.value,
            precio: parseFloat(inputPrecio.value),
            categoria: selectCategoria.value
        }

        opciones.method = 'POST'
        opciones.body = JSON.stringify(nuevoProducto)

        fetch(URLproductos, opciones)
        .then((response)=> response.json() )
        .then((data)=> {
            inputId.value = data.id 
            mostrarMensaje("Producto dado de alta.", "success", 4000)
            obtenerProductos()
        })
        .catch((err)=> {
            let mensaje = `Se ha producido un error: ${err.message}`
            mostrarMensaje(mensaje, 'error', 4500)
        })

    } else if (operacion === 'e') {
        // Modificar producto

        let productoModificado = {
            imagen: inputImagen.value,
            nombre: inputNombre.value,
            precio: parseFloat(inputPrecio.value),
            categoria: selectCategoria.value
        }

        opciones.method = 'PUT'
        opciones.body = JSON.stringify(productoModificado)

        fetch(`${URLproductos}/${inputId.value}`, opciones)
        .then((response)=> response.json() )
        .then((data)=> {
            mostrarMensaje("Producto modificado exitosamente.", "success", 4000)
            obtenerProductos()

        })
        .catch((err)=> {
            let mensaje = `Se ha producido un error: ${err.message}`
            mostrarMensaje(mensaje, 'error', 4500)
        })
    }

})

btnEliminar.addEventListener("click", ()=> {
    opciones.method = 'DELETE'
    opciones.body = ''    

    fetch(`${URLproductos}/${inputId.value}`, opciones)
    .then((response)=> response.json() )
    .then((data)=> {
        console.table(data)
        mostrarMensaje("Producto eliminado exitosamente.", "alert", 4000)
        obtenerProductos()
    })
    .catch((err)=> {
        let mensaje = `Se ha producido un error: ${err.message}`
        mostrarMensaje(mensaje, 'error', 4500)
    })
})