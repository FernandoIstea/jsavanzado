/*
URL BASE: "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/"
ENDPOINT: "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos"

BUSCAR o FILTRAR:

URL params
"https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos/7"

QUERY params
"https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos?categoria=fruta"

"https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos?categoria=fruta&nombre=manzana"

*/