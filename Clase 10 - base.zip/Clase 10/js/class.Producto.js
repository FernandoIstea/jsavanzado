class Producto {
    constructor(id, nombre, precio, moneda, stock) {
        this.id = parseInt(id)
        this.nombre = nombre
        this.precio = parseFloat(precio)
        this.moneda = moneda
        this.stock = parseInt(stock)
    }

    mostrarNombreMayuscula() {
        return this.nombre.toUpperCase()
    }

    retornarPrecioEnARS(coti) {
        if (this.precio !== '' && this.precio > 0) {
            let resultado = this.precio * coti
            return resultado.toLocaleString()
        } else {
            console.error("La propiedad 'precio' debe tener un dato válido.")
        }
    }

    descontarStock(unidades) {
        if (unidades > 0 && unidades <= this.stock) {
            let nuevoStock = this.stock - unidades
            this.stock = nuevoStock

            return nuevoStock
        } else {
            console.warn("Verifique el valor de las unidades:", unidades)
        }
    }
}



// EJEMPLO DE USO DE 'Producto'
const arrayProds = []

function agregarProducto() {
    let codigo = prompt("Ingresa el código de producto:")
    let nombre = prompt("Ingresa el nombre de producto:")
    let precio = prompt("Ingresa el precio de producto:")
    let moneda = 'USD'
    let stock = prompt("Ingresa el Stock del producto:")

    let nuevoProducto = new Producto(codigo, nombre, precio, moneda, stock)
    arrayProds.push(nuevoProducto)
}



// OBJETOS LITERALES
/*
const Persona = {
    nombre: 'Fer',
    apellido: 'Moon',
    anioNacimiento: 1975,
    profesion: 'Analista Técnico Funcional',
    mostrarNombreCompleto: function() {
        return `${this.nombre} ${this.apellido}`
    },
    calcularEdad: function() {
        let anioActual = new Date().getFullYear()

        let edad = anioActual - this.anioNacimiento

        return edad 
    }
}

const Producto = {
    id: 1,
    nombre: 'Notebook i7 16GB RAM',
    precio: 1200,
    moneda: 'USD',
    stock: 25,
    mostrarNombreMayuscula: function() {
        return this.nombre.toUpperCase()
    },
    retornarPrecioEnARS: function(coti) {
        if (this.precio !== '' && this.precio > 0 ) {
            let resultado = this.precio * coti
            return resultado.toLocaleString()
        } else {
            console.error("La propiedad 'precio' debe tener un dato válido.")
        }
    },
    descontarStock: function(unidades) {
        if (unidades > 0 && unidades <= this.stock) {
            let nuevoStock = this.stock - unidades 
            this.stock = nuevoStock

            return nuevoStock
        } else {
            console.warn("Verifique el valor de las unidades:", unidades)
        }
    }
}
*/

// FUNCIONES CONSTRUCTORAS

class Persona {
    constructor(nombre, apellido, anioNacimiento) {
        this.nombre = nombre
        this.apellido = apellido
        this.anioNacimiento = anioNacimiento
    }
    mostrarNombreCompleto() {
        let nombreCompleto = `${this.nombre} ${this.apellido}`    
        return nombreCompleto
    }
}

const profe = new Persona('Fer', 'Moon', 1975)
const mecanico = new Persona('Nico', 'Moon', 1997)

