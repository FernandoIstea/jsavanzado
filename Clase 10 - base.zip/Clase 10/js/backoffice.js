const dialog = document.querySelector("dialog")

const btnNuevo = document.querySelector("button.btn-nuevo")
const btnGuardar = document.querySelector("button#btnGuardar")
const btnEliminar = document.querySelector("button#btnEliminar")

const inputId = document.querySelector("input#inputId")
const inputImagen = document.querySelector("input#inputImagen")
const inputNombre = document.querySelector("input#inputNombre")
const inputPrecio = document.querySelector("input#inputPrecio")
const selectCategoria = document.querySelector("select#selectCategoria")

const tableBody = document.querySelector("table tbody#tableBody")

const URLproductos = "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos"

let operacion = "" // (n = nuevo - e = editar)
const productos = []

function armarFilaHTML(producto) {
    return `<tr data-filaCodigo="${producto.id}">
                <td id="pImagen">${producto.imagen}</td>
                <td id="nombre">${producto.nombre}</td>
                <td id="price">$ ${producto.precio.toLocaleString()}</td>
                <td id="categoría">${producto.categoria}</td>
                <td id="delButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para eliminar">
                    ⛔️
                </td>
                <td id="editButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para Modificar">
                    ✍️
                </td>
            </tr>`
}

function mostrarMensaje(mensaje, estilo, timer) {
    ToastIt.now({
        message: mensaje,
        style: estilo,
        close: false,
        timer: timer,
        position: ''
    })
}

// Función principal


// EVENTOS
btnNuevo.addEventListener("click", ()=> {})

btnGuardar.addEventListener("click", ()=> {})

btnEliminar.addEventListener("click", ()=> {})