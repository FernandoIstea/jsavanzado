const btnComprar = document.querySelector("button#btnBuy")
const btnVolver = document.querySelector("button#btnReturn")
const totalCarrito = document.querySelector("td#totalPrice")
const tableBody = document.querySelector("tbody#tableBody")

function mostrarMensaje(mensaje, estilo) {
    ToastIt.now({
            close: true,
            style: estilo,       // info, success, warn, error
            timer: 3700,
            message: mensaje,
            position: 'right'
        }
    )
}

function crearFilaProducto(prod) {
    return `<tr>
                <td id="pImagen">${prod.imagen}</td>
                <td id="nombre">${prod.nombre}</td>
                <td id="price">$ ${prod.precio}</td>
                <td id="delButton" 
                    data-codigo="${prod.id}" 
                    title="Clic para eliminar">
                    ❌
                </td>
            </tr>`
}

function cargarCarritoCompras() {
    ShoppingCart.restoreShoppingCart()

    if (ShoppingCart.cartList.length > 0) {
        let grillaProductos = ""
        ShoppingCart.cartList.forEach((prod)=> grillaProductos += crearFilaProducto(prod) )
        tableBody.innerHTML = grillaProductos
        totalCarrito.textContent = ShoppingCart.calculateTotalAmount()
        activarEventosClickQuitarProd()
        btnComprar.removeAttribute("disabled")
    } else {
        retornarAhome()
    }
}

function retornarAhome() {
    location.href = "index.html"
}

function activarEventosClickQuitarProd() {
    const botonesQuitar = document.querySelectorAll("td#delButton")

    if (botonesQuitar.length > 0) {
        botonesQuitar.forEach((botonQuitar)=> {
            botonQuitar.addEventListener("click", ()=> {
                let productoQuitado = ShoppingCart.removeItem(botonQuitar.dataset.codigo)         
                ShoppingCart.saveShoppingCart()       
                mostrarMensaje(`${productoQuitado[0].nombre} quitado del array.`, "alert")
                cargarCarritoCompras()
            })
        })
    }
}
 
// Función Principal
cargarCarritoCompras()

// EVENTOS
btnComprar.addEventListener("click", ()=> {
    mostrarMensaje("🛍️ Compra finalizada. Muchas gracias por elegirnos!", "success")
    ShoppingCart.cartList.length = 0
    localStorage.removeItem("carrito")
    setTimeout(() => retornarAhome(), 3500)
})

btnVolver.addEventListener("click", ()=> retornarAhome() )