// declarar variables, constantes, y enlaces al DOM HTML
const URLproductos = "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos"
const productos = []
const categorias = []

const categoriasContainer = document.querySelector("#categoriasContainer")
const cardContainer = document.querySelector("div.card-container")
const inputSearch = document.querySelector("input#inputSearch")
const buttonCarrito = document.querySelector("div.shoping-cart")
const divArrow = document.querySelector("div#arrow-up")

ShoppingCart.restoreShoppingCart()

function generarCategoriasUnicas() {
    const mapearCategorias = productos.map((prod) => prod.categoria)
    const arrayCategoriasUnicas = [...new Set(mapearCategorias)]

    return arrayCategoriasUnicas
}

function mostrarMensaje(mensaje, estilo) {
    ToastIt.now({
        close: true,
        style: estilo,       // info, success, alert, error
        timer: 3700,
        message: mensaje,
        position: 'right'    // left, center, 'right = optional'
    }
    )
}

function crearCardHTML(producto) {

    return `<div class="card">
                <div class="product-image" data-image="${producto.id}">${producto.imagen}</div>
                <div class="product-name">${producto.nombre}</div>
                <div class="product-price">$ ${producto.precio.toLocaleString()}</div>
                <div class="buy-button">
                    <button id="buttonComprar" data-codigo="${producto.id}" >COMPRAR</button>
                </div>
            </div>`
}

function crearCardErrorHTML() {
    return `<div class="card-error">
                <div class="error-title">
                    <h3>Se ha producido un error inesperado.</h3>
                    <div class="emoji-error">🔌</div>
                    <h4>Por favor, intenta acceder nuevamente en unos instantes.</h4>
                    <p>No estamos pudiendo cargar el listado de productos para tu compra.</p>
                    <div class="emoji-error">
                        <span>🥑</span>
                        <span>🍉</span>
                        <span>🍋‍🟩</span>
                        <span>🍏</span>
                    </div>
                </div>
            </div>`
}

function crearCategoria(cate) {
    const categoriaSpan = document.createElement("span")
    categoriaSpan.textContent = cate
    categoriaSpan.id = "categoriaId"
    categoriaSpan.className = "category"

    return categoriaSpan
}

function cargarCategorias() {
    categorias.push(...generarCategoriasUnicas() )

    for (let categoria of categorias) {
        let spanHTML = crearCategoria(categoria)
        categoriasContainer.appendChild(spanHTML)
    }
}

function activarFiltrosPorCategoria() {
    const spanCategorias = document.querySelectorAll("span#categoriaId")

    spanCategorias.forEach((categoria) => {
        categoria.addEventListener("click", () => {
            if (categoria.textContent === "Todos") {
                cargarProductos(productos)
            } else {
                const productosFiltrados = productos.filter((prod) => prod.categoria === categoria.textContent)
                cargarProductos(productosFiltrados)
            }
            activarEventosClickBtnComprar()
        })
    })
}

function activarEventosClickBtnComprar() {
    const botonesComprar = document.querySelectorAll("button#buttonComprar")

    botonesComprar.forEach((botonComprar) => {
        botonComprar.addEventListener("click", () => {
            const productoSeleccionado = productos.find((prod) => prod.id === botonComprar.dataset.codigo)
            ShoppingCart.cartList.push(productoSeleccionado)
            ShoppingCart.saveShoppingCart()
            const divProductImage = document.querySelector(`div [data-image="${botonComprar.dataset.codigo}"]`)
            divProductImage.classList.add("girar-trompo")
            divProductImage.addEventListener("animationend", ()=> divProductImage.classList.remove("girar-trompo") )
            let mensajeToast = `${productoSeleccionado.nombre} agregado al carrito`
            mostrarMensaje(mensajeToast, "success")
        })
    })
}

function cargarProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        cardContainer.innerHTML = ""
        arrayProductos.forEach((producto) => cardContainer.innerHTML += crearCardHTML(producto))
    }
}

function agruparPorCategoria() {
    const productosAgrupados = Object.groupBy(productos, (prod) => prod.categoria)

    categoriasContainer.remove()
    cardContainer.innerHTML = ""
    for (let cat in productosAgrupados) {
        cardContainer.innerHTML += crearCategoriaDiv(cat)
        productosAgrupados[cat].forEach((prod) => cardContainer.innerHTML += crearCardHTML(prod))
    }
    activarEventosClickBtnComprar()
}

function obtenerProductos() {
    fetch(URLproductos)
    .then((response)=> response.json() )
    .then((data)=> productos.push(...data) )
    .then(()=> {
        cargarCategorias()
        activarFiltrosPorCategoria()
        cargarProductos(productos)
        activarEventosClickBtnComprar()
    })
    .catch((error)=> {
        console.error("Se ha producido un error:", error.message)
        cardContainer.innerHTML = crearCardErrorHTML()
    } )
}

obtenerProductos()
// agruparPorCategoria()   // alternativa 2

// EVENTOS JS sobre elementos HTML
inputSearch.addEventListener("keypress", (event) => {

    const condicionOk = event.key === "Enter" && inputSearch.value.trim() !== "" && inputSearch.value.length >= 3

    if (condicionOk) {
        let parametro = inputSearch.value.trim().toLowerCase() // normalizamos el dato

        const productosFiltrados = productos.filter((prod) => prod.nombre.toLowerCase().includes(parametro))

        if (productosFiltrados.length > 0) {
            cargarProductos(productosFiltrados)
            activarEventosClickBtnComprar()
        } else {
            mostrarMensaje("No se encontraron coincidencias.", "alert")
        }
    }
})

buttonCarrito.addEventListener("mousemove", () => {
    if (ShoppingCart.cartList.length === 0) {
        buttonCarrito.title = "Agrega productos al carrito"
    } else {
        buttonCarrito.title = ShoppingCart.cartList.length + " producto(s) en carrito"
    }
})

buttonCarrito.addEventListener("click", (event) => {
    if (navigator.onLine === false) {
        return
    }

    if (ShoppingCart.cartList.length > 0) {
        location.href = "checkout.html"
    } else {
        alert("⚠️ Agrega productos al carrito.")
    }
})

window.addEventListener("offline", () => {
    mostrarMensaje("Has perdido conexión a Internet.", "error")
})

window.addEventListener("online", () => {
    mostrarMensaje("Ha vuelto la conectividad a Internet.", "info")
})

divArrow.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
})

document.addEventListener("scroll", () => {
    if (window.scrollY > 300) {
        divArrow.classList.remove("hide-arrow")
    } else {
        divArrow.classList.add("hide-arrow")
    }
})