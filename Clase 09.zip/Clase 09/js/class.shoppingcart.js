class ShoppingCart {
    static cartList = []

    static restoreShoppingCart() {
        let stringCarrito = localStorage.getItem("carrito")

        if (stringCarrito === null) {
            console.error("Error al intentar recuperar el carrito.")
        } else {
            let carritoRecuperado = JSON.parse(stringCarrito)
            ShoppingCart.cartList = carritoRecuperado
        }
    }

    static saveShoppingCart() {
        let carritoString = JSON.stringify(ShoppingCart.cartList)
        localStorage.setItem("carrito", carritoString)
        return "Ok"
    }

    static calculateTotalAmount() {
        const totalCarrito = this.cartList.reduce((acc, prod)=> acc + prod.precio, 0 )

        return totalCarrito.toLocaleString("es-AR", { style: 'currency', currency: 'ARS' })
    }

    static removeItem(itemId) {
        if (typeof parseInt(itemId) === 'number') {
            let indiceProd = ShoppingCart.cartList.findIndex((prod)=> prod.id === itemId)
            if (indiceProd > -1) {
                let productoQuitado = ShoppingCart.cartList.splice(indiceProd, 1)
                return productoQuitado
            } else {
                return "⛔️ Error al quitar el producto."
            }
        } else {
            return "⛔️ Error en el dato enviado."
        }
    } 

    static calculateTotalProducts() {
        if (ShoppingCart.cartList.length > 0) {
            return ShoppingCart.cartList.length
        } else {
            return 0
        }
    }
}