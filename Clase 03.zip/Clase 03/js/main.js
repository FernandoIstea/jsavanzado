// declarar variables, constantes, y enlaces al DOM HTML
const carrito = []
const categoriasContainer = document.getElementById("categoriasContainer")
const cardContainer = document.querySelector("div.card-container")

function crearCardHTML(producto) {

    return `<div class="card">
                <div class="product-image">${producto.imagen}</div>
                <div class="product-name">${producto.nombre}</div>
                <div class="product-price">$ ${producto.precio}</div>
                <div class="buy-button">
                    <button id="buttonComprar" data-codigo="${producto.id}" >COMPRAR</button>
                </div>
            </div>`
}

function crearCardErrorHTML() {
    return `<div class="card-error">
                <div class="error-title">
                    <h3>Se ha producido un error inesperado.</h3>
                    <div class="emoji-error">🔌</div>
                    <h4>Por favor, intenta acceder nuevamente en unos instantes.</h4>
                    <p>No estamos pudiendo cargar el listado de productos para tu compra.</p>
                    <div class="emoji-error">
                        <span>🥑</span>
                        <span>🍉</span>
                        <span>🍋‍🟩</span>
                        <span>🍏</span>
                    </div>
                </div>
            </div>`
}

function crearCategoria(cate) {
    const categoriaSpan = document.createElement("span") 
    categoriaSpan.textContent = cate
    categoriaSpan.id = "categoriaId"
    categoriaSpan.className = "category"

    return categoriaSpan
}

function cargarCategorias() {    
    for (let categoria of categorias) {
        let spanHTML = crearCategoria(categoria)
        categoriasContainer.appendChild(spanHTML)
    }
}

function activarEventosClickBtnComprar() {
    const botonesComprar = document.querySelectorAll("button#buttonComprar")

    for (let botonComprar of botonesComprar) {
        botonComprar.onclick = function() { //definir evento click
            console.log(botonComprar.dataset.codigo) 
            // buscarlo en un array (productos) todo el obj literal, usando el ID
            // agregar ese 'producto' a otro array carrito[]
        } 
    }
}

function cargarProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        cardContainer.innerHTML = ""
        for (let producto of arrayProductos) {
            cardContainer.innerHTML += crearCardHTML(producto)
        }
    } else {
        cardContainer.innerHTML = crearCardErrorHTML()
    }
}

function armarContenido() {
    cargarCategorias()
    cargarProductos(productos)
    // activación de evento click en botones COMPRAR
}

// Función principal (una sola función)
armarContenido()


// Eventos JS sobre elementos HTML
