// declarar variables, constantes, y enlaces al DOM HTML
const carrito = []
const categoriasContainer = document.querySelector("#categoriasContainer")
const cardContainer = document.querySelector("div.card-container")
const inputSearch = document.querySelector("input#inputSearch")
const buttonCarrito = document.querySelector("div.shoping-cart")

function crearCardHTML(producto) {

    return `<div class="card">
                <div class="product-image">${producto.imagen}</div>
                <div class="product-name">${producto.nombre}</div>
                <div class="product-price">$ ${producto.precio}</div>
                <div class="buy-button">
                    <button id="buttonComprar" data-codigo="${producto.id}" >COMPRAR</button>
                </div>
            </div>`
}

function crearCardErrorHTML() {
    return `<div class="card-error">
                <div class="error-title">
                    <h3>Se ha producido un error inesperado.</h3>
                    <div class="emoji-error">🔌</div>
                    <h4>Por favor, intenta acceder nuevamente en unos instantes.</h4>
                    <p>No estamos pudiendo cargar el listado de productos para tu compra.</p>
                    <div class="emoji-error">
                        <span>🥑</span>
                        <span>🍉</span>
                        <span>🍋‍🟩</span>
                        <span>🍏</span>
                    </div>
                </div>
            </div>`
}

function crearCategoria(cate) {
    const categoriaSpan = document.createElement("span") 
    categoriaSpan.textContent = cate
    categoriaSpan.id = "categoriaId"
    categoriaSpan.className = "category"

    return categoriaSpan
}

function cargarCategorias() {    
    for (let categoria of categorias) {
        let spanHTML = crearCategoria(categoria)
        categoriasContainer.appendChild(spanHTML)
    }
}

function activarFiltrosPorCategoria() {
    const spanCategorias = document.querySelectorAll("span#categoriaId")

    for (let categoria of spanCategorias) {
        categoria.addEventListener("click", ()=> {
            if (categoria.textContent === "Todos") {
                cargarProductos(productos)
            } else {
                const productosFiltrados = []
                for (let prod of productos) {
                    if (prod.categoria === categoria.textContent) {
                        productosFiltrados.push(prod)
                    }
                }
                cargarProductos(productosFiltrados)
            }
            activarEventosClickBtnComprar()
        })
    }
}

function activarEventosClickBtnComprar() {
    const botonesComprar = document.querySelectorAll("button#buttonComprar")

    for (let botonComprar of botonesComprar) {
        botonComprar.onclick = function() { 
            for (let prod of productos) {
                if (prod.id === botonComprar.dataset.codigo) { // encontramos la coincidencia
                    carrito.push(prod)                         // guardamos copia en carrito
                    console.clear()
                    console.table(carrito)
                    break 
                }
            }
        } 
    }
}

function cargarProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        cardContainer.innerHTML = ""
        for (let producto of arrayProductos) {
            cardContainer.innerHTML += crearCardHTML(producto)
        }
    } else {
        cardContainer.innerHTML = crearCardErrorHTML()
    }
}

function armarContenido() {
    cargarCategorias()
    cargarProductos(productos)
    activarEventosClickBtnComprar()
    activarFiltrosPorCategoria()
}

// Función principal (una sola función)
armarContenido()


// EVENTOS JS sobre elementos HTML

inputSearch.addEventListener("keypress", (event)=> {
    if (event.key === "Enter" && inputSearch.value.trim() !== "") {
        const productosFiltrados = []
        let parametro = inputSearch.value.trim().toLowerCase() // normalización
        for (let prod of productos) {
            if (prod.nombre.toLowerCase().includes(parametro)) {
                productosFiltrados.push(prod)
            }
        }
        cargarProductos(productosFiltrados)
        activarEventosClickBtnComprar()
    } else {
        // no se encontraron resultados.
    }
})

buttonCarrito.addEventListener("mousemove", ()=> {
    if (carrito.length === 0) {
        buttonCarrito.title = "Agrega productos al carrito"
    } else {
        buttonCarrito.title = carrito.length + " producto(s) en carrito"
    }
})

buttonCarrito.addEventListener("click", ()=> {
    if (carrito.length > 0) {
        location.href = "checkout.html"
    } else {
        alert("⚠️ Agrega productos al carrito.")
    }
}) 