// IMPORTS 
import { mostrarMensaje, URLproductos, crearCategoria, 
         crearCardHTML, crearCardErrorHTML } from "./utils.js"

import { ShoppingCart } from "./class.shoppingcart.js"

// VARIABLES, CONSTANTES, y enlaces al DOM HTML

const productos = []
const categorias = []

const categoriasContainer = document.querySelector("#categoriasContainer")
const cardContainer = document.querySelector("div.card-container")
const inputSearch = document.querySelector("input#inputSearch")
const buttonCarrito = document.querySelector("div.shoping-cart")
const divArrow = document.querySelector("div#arrow-up")


// LÒGICA
ShoppingCart.restoreShoppingCart()

function generarCategoriasUnicas() {
    const mapearCategorias = productos.map((prod) => prod.categoria)
    const arrayCategoriasUnicas = [...new Set(mapearCategorias)]

    return arrayCategoriasUnicas
}

function cargarCategorias() {
    categorias.push(...generarCategoriasUnicas() )

    for (let categoria of categorias) {
        let spanHTML = crearCategoria(categoria)
        categoriasContainer.appendChild(spanHTML)
    }
}

function activarFiltrosPorCategoria() {
    const spanCategorias = document.querySelectorAll("span#categoriaId")

    spanCategorias.forEach((categoria) => {
        categoria.addEventListener("click", () => {
            if (categoria.textContent === "Todos") {
                cargarProductos(productos)
            } else {
                const productosFiltrados = productos.filter((prod) => prod.categoria === categoria.textContent)
                cargarProductos(productosFiltrados)
            }
            activarEventosClickBtnComprar()
        })
    })
}

function activarEventosClickBtnComprar() {
    const botonesComprar = document.querySelectorAll("button#buttonComprar")

    botonesComprar.forEach((botonComprar) => {
        botonComprar.addEventListener("click", () => {
            const productoSeleccionado = productos.find((prod) => prod.id === botonComprar.dataset.codigo)
            ShoppingCart.cartList.push(productoSeleccionado)
            ShoppingCart.saveShoppingCart()
            const divProductImage = document.querySelector(`div [data-image="${botonComprar.dataset.codigo}"]`)
            divProductImage.classList.add("girar-trompo")
            divProductImage.addEventListener("animationend", ()=> divProductImage.classList.remove("girar-trompo") )
            let mensajeToast = `${productoSeleccionado.nombre} agregado al carrito`
            mostrarMensaje(mensajeToast, "success")
        })
    })
}

function cargarProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        cardContainer.innerHTML = ""
        arrayProductos.forEach((producto) => cardContainer.innerHTML += crearCardHTML(producto))
    }
}

function agruparPorCategoria() {
    const productosAgrupados = Object.groupBy(productos, (prod) => prod.categoria)

    categoriasContainer.remove()
    cardContainer.innerHTML = ""
    for (let cat in productosAgrupados) {
        cardContainer.innerHTML += crearCategoriaDiv(cat)
        productosAgrupados[cat].forEach((prod) => cardContainer.innerHTML += crearCardHTML(prod))
    }
    activarEventosClickBtnComprar()
}

// ASYNC AWAIT (syntactic sugar) + Try Catch statement

async function obtenerProds() {
    try {
        const response = await fetch(URLproductos)

        if (response.status !== 200) {
            throw new Error("Error al intentar obtener productos.")
        }
        const data = await response.json()
        productos.push(...data)
        cargarCategorias()
        activarFiltrosPorCategoria()
        cargarProductos(productos)
        activarEventosClickBtnComprar()
    } catch (error) {
        console.error("Se ha producido un error:", error.message)
        cardContainer.innerHTML = crearCardErrorHTML()
    }
}

function obtenerProductos() {
    fetch(URLproductos)
    .then((response)=> response.json() )
    .then((data)=> productos.push(...data) )
    .then(()=> {
        cargarCategorias()
        activarFiltrosPorCategoria()
        cargarProductos(productos)
        activarEventosClickBtnComprar()
    }).catch((error)=> {
        console.error("Se ha producido un error:", error.message)
        cardContainer.innerHTML = crearCardErrorHTML()
    } )
}

obtenerProds()
// obtenerProductos()
// agruparPorCategoria()   // alternativa 2

// EVENTOS JS sobre elementos HTML
inputSearch.addEventListener("keypress", (event) => {

    const condicionOk = event.key === "Enter" && inputSearch.value.trim() !== "" && inputSearch.value.length >= 3

    if (condicionOk) {
        let parametro = inputSearch.value.trim().toLowerCase() // normalizamos el dato

        const productosFiltrados = productos.filter((prod) => prod.nombre.toLowerCase().includes(parametro))

        if (productosFiltrados.length > 0) {
            cargarProductos(productosFiltrados)
            activarEventosClickBtnComprar()
        } else {
            mostrarMensaje("No se encontraron coincidencias.", "alert")
        }
    }
})

buttonCarrito.addEventListener("mousemove", () => {

    buttonCarrito.title = ShoppingCart.cartList.length === 0 ? "Agrega productos al carrito"
                                                             : ShoppingCart.cartList.length + " producto(s) en carrito"

    // ShoppingCart.cartList.length === 0 ? buttonCarrito.title = "Agrega productos al carrito"
    //                                    : buttonCarrito.title = ShoppingCart.cartList.length + " producto(s) en carrito"

    // if (ShoppingCart.cartList.length === 0) {
    //     buttonCarrito.title = "Agrega productos al carrito"
    // } else {
    //     buttonCarrito.title = ShoppingCart.cartList.length + " producto(s) en carrito"
    // }
})

buttonCarrito.addEventListener("click", (event) => {
        ShoppingCart.cartList.length > 0 ? location.href = "checkout.html" 
                                         : alert("⚠️ Agrega productos al carrito.")

    // if (navigator.onLine === true) {
    //     ShoppingCart.cartList.length > 0 ? location.href = "checkout.html" 
    //                                      : alert("⚠️ Agrega productos al carrito.")
    // }
})

window.addEventListener("offline", () => {
    mostrarMensaje("Has perdido conexión a Internet.", "error")
})

window.addEventListener("online", () => {
    mostrarMensaje("Ha vuelto la conectividad a Internet.", "info")
})

divArrow.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
})

document.addEventListener("scroll", () => {
    window.scrollY > 300 ? divArrow.classList.remove("hide-arrow") 
                         : divArrow.classList.add("hide-arrow")

    // if (window.scrollY > 300) {
    //     divArrow.classList.remove("hide-arrow")
    // } else {
    //     divArrow.classList.add("hide-arrow")
    // }
})