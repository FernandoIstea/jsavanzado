// IMPORTS 
import { ToastIt } from "./toastitv1.1.min.js"

export const URLproductos = "https://686949c32af1d945cea17ff4.mockapi.io/api/v1/productos"

export const opciones = {
    method: '',
    headers: { 'content-type': 'application/json'},
    body: ''
}

export function mostrarMensaje(mensaje, estilo) {
    ToastIt.now({
        close: true,
        style: estilo,       // info, success, alert, error
        timer: 3700,
        message: mensaje,
        position: 'right'    // left, center, 'right = optional'
    })
}

export function crearCategoria(cate) {
    const categoriaSpan = document.createElement("span")
    categoriaSpan.textContent = cate
    categoriaSpan.id = "categoriaId"
    categoriaSpan.className = "category"

    return categoriaSpan
}

export function crearFilaProducto(prod) {
    return `<tr>
                <td id="pImagen">${prod.imagen}</td>
                <td id="nombre">${prod.nombre}</td>
                <td id="price">$ ${prod.precio}</td>
                <td id="delButton" 
                    data-codigo="${prod.id}" 
                    title="Clic para eliminar">
                    ❌
                </td>
            </tr>`
}

export function crearCardHTML({id, nombre, precio, imagen }) {

    return `<div class="card">
                <div class="product-image" data-image="${id}">${imagen}</div>
                <div class="product-name">${nombre}</div>
                <div class="product-price">$ ${precio.toLocaleString()}</div>
                <div class="buy-button">
                    <button id="buttonComprar" data-codigo="${id}" >COMPRAR</button>
                </div>
            </div>`
}

export function crearCardErrorHTML() {
    return `<div class="card-error">
                <div class="error-title">
                    <h3>Se ha producido un error inesperado.</h3>
                    <div class="emoji-error">🔌</div>
                    <h4>Por favor, intenta acceder nuevamente en unos instantes.</h4>
                    <p>No estamos pudiendo cargar el listado de productos para tu compra.</p>
                    <div class="emoji-error">
                        <span>🥑</span>
                        <span>🍉</span>
                        <span>🍋‍🟩</span>
                        <span>🍏</span>
                    </div>
                </div>
            </div>`
}


export function armarFilaHTML(producto) {
    return `<tr data-filaCodigo="${producto.id}">
                <td id="pImagen">${producto.imagen}</td>
                <td id="nombre">${producto.nombre}</td>
                <td id="price">$ ${producto.precio.toLocaleString()}</td>
                <td id="categoría">${producto.categoria}</td>
                <td id="delButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para eliminar">
                    ⛔️
                </td>
                <td id="editButton" 
                    data-codigo="${producto.id}" 
                    title="Clic para Modificar">
                    ✍️
                </td>
            </tr>`
}