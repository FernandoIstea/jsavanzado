// IMPORTS 
import { URLproductos, mostrarMensaje, 
         armarFilaHTML, opciones } from "./utils.js"

let operacion = "" // (n = nuevo - e = editar)
const dialog = document.querySelector("dialog")

const btnNuevo = document.querySelector("button.btn-nuevo")
const btnGuardar = document.querySelector("button#btnGuardar")
const btnEliminar = document.querySelector("button#btnEliminar")

const inputId = document.querySelector("input#inputId")
const inputImagen = document.querySelector("input#inputImagen")
const inputNombre = document.querySelector("input#inputNombre")
const inputPrecio = document.querySelector("input#inputPrecio")
const selectCategoria = document.querySelector("select#selectCategoria")

const tableBody = document.querySelector("table tbody#tableBody")

const productos = []

function obtenerProductos() {
    fetch(URLproductos)
    .then((response)=> response.json() )
    .then((data)=> {
        productos.length = 0
        productos.push(...data)
    })
    .then(()=> {
        cargarProductos()
        activarClicEditarProducto()
        activarClicEliminarProducto()
    } )
    .catch((err)=> {
        let mensaje = `Se ha producido un error: ${err.message}`
        mostrarMensaje(mensaje, 'error')
    } )
}

function activarClicEditarProducto() {
    const botonesEditar = document.querySelectorAll("td#editButton")

    if (botonesEditar.length > 0) {
        botonesEditar.forEach((botonEditar)=> {
            botonEditar.addEventListener("click", ()=> {
                let productoAeditar = productos.find((prod)=> prod.id === botonEditar.dataset.codigo )
                inputId.value = productoAeditar.id 
                inputImagen.value = productoAeditar.imagen 
                inputNombre.value = productoAeditar.nombre 
                inputPrecio.value = productoAeditar.precio
                selectCategoria.value = productoAeditar.categoria
                btnEliminar.setAttribute('hidden', 'true')
                btnGuardar.removeAttribute('hidden')
                operacion = 'e'
                dialog.showModal()
            })
        })
    }
}

function activarClicEliminarProducto() {
    const botonesEliminar = document.querySelectorAll("td#delButton")

    if (botonesEliminar.length > 0) {
        botonesEliminar.forEach((botonEliminar)=> {
            botonEliminar.addEventListener("click", ()=> {

                let productoAquitar = productos.find((prod)=> prod.id === botonEliminar.dataset.codigo )
                inputId.value = productoAquitar.id 
                inputImagen.value = productoAquitar.imagen 
                inputNombre.value = productoAquitar.nombre 
                inputPrecio.value = productoAquitar.precio
                selectCategoria.value = productoAquitar.categoria
                btnEliminar.removeAttribute('hidden')
                btnGuardar.setAttribute('hidden', 'true')
                dialog.showModal()

            })
        })
    }
}

function cargarProductos() {
    if (productos.length > 0) {
        let filasProductos = ""
        productos.forEach((prod)=> filasProductos += armarFilaHTML(prod) )
        tableBody.innerHTML = filasProductos
    }
}

// Función principal
obtenerProductos()

// EVENTOS
btnNuevo.addEventListener("click", ()=> {
    operacion = 'n'
    btnEliminar.setAttribute('hidden', 'true')
    btnGuardar.removeAttribute('hidden')
    inputId.value = ""
    inputImagen.value = ""   
    inputNombre.value = ""   
    inputPrecio.value = ""   
    selectCategoria.value = selectCategoria[0].value
    dialog.showModal()
})

btnGuardar.addEventListener("click", ()=> {
    if (operacion === 'n') {
        // nuevo producto
        // validar campos con contenido (id, nombre, imagen, precio, cate)
        let nuevoProducto = {
            imagen: inputImagen.value,
            nombre: inputNombre.value,
            precio: parseFloat(inputPrecio.value),
            categoria: selectCategoria.value
        }

        opciones.method = 'POST'
        opciones.body = JSON.stringify(nuevoProducto)

        fetch(URLproductos, opciones)
        .then((response)=> response.json() )
        .then((data)=> {
            inputId.value = data.id 
            mostrarMensaje("Producto dado de alta.", "success")
            obtenerProductos()
        })
        .catch((err)=> {
            let mensaje = `Se ha producido un error: ${err.message}`
            mostrarMensaje(mensaje, 'error')
        })

    } else if (operacion === 'e') {
        // Modificar producto

        let productoModificado = {
            imagen: inputImagen.value,
            nombre: inputNombre.value,
            precio: parseFloat(inputPrecio.value),
            categoria: selectCategoria.value
        }

        opciones.method = 'PUT'
        opciones.body = JSON.stringify(productoModificado)

        fetch(`${URLproductos}/${inputId.value}`, opciones)
        .then((response)=> response.json() )
        .then((data)=> {
            mostrarMensaje("Producto modificado exitosamente.", "success")
            obtenerProductos()

        })
        .catch((err)=> {
            let mensaje = `Se ha producido un error: ${err.message}`
            mostrarMensaje(mensaje, 'error')
        })
    }

})

btnEliminar.addEventListener("click", ()=> {
    opciones.method = 'DELETE'
    opciones.body = ''    

    fetch(`${URLproductos}/${inputId.value}`, opciones)
    .then((response)=> response.json() )
    .then((data)=> {
        mostrarMensaje("Producto eliminado exitosamente.", "alert")
        obtenerProductos()
    })
    .catch((err)=> {
        let mensaje = `Se ha producido un error: ${err.message}`
        mostrarMensaje(mensaje, 'error')
    })
})