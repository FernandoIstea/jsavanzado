import { crearFilaProducto, mostrarMensaje } from "./utils.js"
import { ShoppingCart } from "./class.shoppingcart.js"

const btnComprar = document.querySelector("button#btnBuy")
const btnVolver = document.querySelector("button#btnReturn")
const totalCarrito = document.querySelector("td#totalPrice")
const tableBody = document.querySelector("tbody#tableBody")

function cargarCarritoCompras() {
    ShoppingCart.restoreShoppingCart()

    if (ShoppingCart.cartList.length > 0) {
        let grillaProductos = ""
        ShoppingCart.cartList.forEach((prod)=> grillaProductos += crearFilaProducto(prod) )
        tableBody.innerHTML = grillaProductos
        totalCarrito.textContent = ShoppingCart.calculateTotalAmount()
        activarEventosClickQuitarProd()
        btnComprar.removeAttribute("disabled")
    } else {
        retornarAhome()
    }
}

function retornarAhome() {
    location.href = "index.html"
}

function activarEventosClickQuitarProd() {
    const botonesQuitar = document.querySelectorAll("td#delButton")

    if (botonesQuitar.length > 0) {
        botonesQuitar.forEach((botonQuitar)=> {
            botonQuitar.addEventListener("click", ()=> {
                let productoQuitado = ShoppingCart.removeItem(botonQuitar.dataset.codigo)         
                ShoppingCart.saveShoppingCart()       
                mostrarMensaje(`${productoQuitado[0].nombre} quitado del array.`, "alert")
                cargarCarritoCompras()
            })
        })
    }
}
 
// Función Principal
cargarCarritoCompras()

// EVENTOS
btnComprar.addEventListener("click", ()=> {
    mostrarMensaje("🛍️ Compra finalizada. Muchas gracias por elegirnos!", "success")
    ShoppingCart.cartList.length = 0
    localStorage.removeItem("carrito")
    setTimeout(() => retornarAhome(), 3500)
})

btnVolver.addEventListener("click", ()=> retornarAhome() )