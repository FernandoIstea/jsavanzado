const btnComprar = document.querySelector("button#btnBuy")
const btnVolver = document.querySelector("button#btnReturn")
const totalCarrito = document.querySelector("td#totalPrice")
const tableBody = document.querySelector("tbody#tableBody")

// const carritoCompras = []

const carritoCompras = [
    { id: "36", imagen: "🍷", nombre: "Vino", precio: 1800, categoria: "Bebida" },
    { id: "32", imagen: "🧀", nombre: "Queso", precio: 450, categoria: "Comida" },
    { id: "29", imagen: "🍞", nombre: "Pan", precio: 200, categoria: "Comida" },
    { id: "31", imagen: "🍝", nombre: "Pasta", precio: 400, categoria: "Comida" },
    { id: "28", imagen: "🫒", nombre: "Aceitunas", precio: 360, categoria: "Verdura" },
    { id: "22", imagen: "🌶️", nombre: "Pimiento", precio: 450, categoria: "Verdura" },
    { id: "16", imagen: "🍋", nombre: "Limones", precio: 260, categoria: "Fruta" },
]

function calcularTotalCarrito() {
    const totalCarrito = carritoCompras.reduce((acc, prod)=> acc + prod.precio, 0 )

    return totalCarrito.toLocaleString("es-AR", { style: 'currency', currency: 'ARS' })
}

function crearFilaProducto(prod) {
    return `<tr>
                <td id="pImagen">${prod.imagen}</td>
                <td id="nombre">${prod.nombre}</td>
                <td id="price">$ ${prod.precio}</td>
                <td id="delButton" 
                    data-codigo="${prod.id}" 
                    title="Clic para eliminar">
                    ❌
                </td>
            </tr>`
}

function cargarCarritoCompras() {
    if (carritoCompras.length > 0) {
        tableBody.innerHTML = ""

        carritoCompras.forEach((prod)=> {
            tableBody.innerHTML += crearFilaProducto(prod)
        })

        totalCarrito.textContent = calcularTotalCarrito()
        activarEventosClickQuitarProd()
        btnComprar.removeAttribute("disabled")
    } else {
        retornarAhome()
    }
}

function retornarAhome() {
    location.href = "index.html"
}

function activarEventosClickQuitarProd() {
    const botonesQuitar = document.querySelectorAll("td#delButton")
    if (botonesQuitar.length > 0) {
        botonesQuitar.forEach((botonQuitar)=> {
            botonQuitar.addEventListener("click", ()=> {
                let idProd = botonQuitar.dataset.codigo 
                let indiceProd = carritoCompras.findIndex((prod)=> prod.id === idProd)
                carritoCompras.splice(indiceProd, 1)
                console.log("Producto quitado del array.")
                cargarCarritoCompras()
            })
        })
    }
}

// Función Principal
cargarCarritoCompras()


// EVENTOS
btnComprar.addEventListener("click", ()=> {
    alert("🛍️ Compra finalizada. Muchas gracias por elegirnos!")
    carritoCompras.length = 0
    setTimeout(() => retornarAhome(), 2500)
})

btnVolver.addEventListener("click", ()=> retornarAhome())