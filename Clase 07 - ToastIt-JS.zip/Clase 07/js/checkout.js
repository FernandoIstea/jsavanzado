const btnComprar = document.querySelector("button#btnBuy")
const btnVolver = document.querySelector("button#btnReturn")
const totalCarrito = document.querySelector("td#totalPrice")
const tableBody = document.querySelector("tbody#tableBody")

// const carritoCompras = []

function recuperarCarrito() {
    let stringCarrito = localStorage.getItem("carrito")
    if (stringCarrito === null) {
        return []
    }

    let carritoRecuperado = JSON.parse(stringCarrito)
    
    return carritoRecuperado
}

function mostrarMensaje(mensaje, estilo) {
    ToastIt.now({
            close: true,
            style: estilo,       // info, success, warn, error
            timer: 3700,
            message: mensaje,
            position: 'right'
        }
    )
}

function guardarCarrito(carrito) {
    if (carrito.length > 0) {
        let carritoString = JSON.stringify(carrito)
        
        localStorage.setItem("carrito", carritoString)
    }
}

const carritoCompras = recuperarCarrito()

function calcularTotalCarrito() {
    const totalCarrito = carritoCompras.reduce((acc, prod)=> acc + prod.precio, 0 )

    return totalCarrito.toLocaleString("es-AR", { style: 'currency', currency: 'ARS' })
}

function crearFilaProducto(prod) {
    return `<tr>
                <td id="pImagen">${prod.imagen}</td>
                <td id="nombre">${prod.nombre}</td>
                <td id="price">$ ${prod.precio}</td>
                <td id="delButton" 
                    data-codigo="${prod.id}" 
                    title="Clic para eliminar">
                    ❌
                </td>
            </tr>`
}

function cargarCarritoCompras() {
    if (carritoCompras.length > 0) {
        tableBody.innerHTML = ""

        carritoCompras.forEach((prod)=> {
            tableBody.innerHTML += crearFilaProducto(prod)
        })

        totalCarrito.textContent = calcularTotalCarrito()
        activarEventosClickQuitarProd()
        btnComprar.removeAttribute("disabled")
    } else {
        retornarAhome()
    }
}

function retornarAhome() {
    location.href = "index.html"
}

function activarEventosClickQuitarProd() {
    const botonesQuitar = document.querySelectorAll("td#delButton")
    if (botonesQuitar.length > 0) {
        botonesQuitar.forEach((botonQuitar)=> {
            botonQuitar.addEventListener("click", ()=> {
                let idProd = botonQuitar.dataset.codigo 
                let indiceProd = carritoCompras.findIndex((prod)=> prod.id === idProd)
                let productoQuitado = carritoCompras.splice(indiceProd, 1)
                guardarCarrito(carritoCompras)
                let mensajeToast = `${productoQuitado[0].nombre} quitado del array.`
                mostrarMensaje(mensajeToast, "alert")
                cargarCarritoCompras()
            })
        })
    }
}

// Función Principal
cargarCarritoCompras()


// EVENTOS
btnComprar.addEventListener("click", ()=> {
    // alert("🛍️ Compra finalizada. Muchas gracias por elegirnos!")
    mostrarMensaje("🛍️ Compra finalizada. Muchas gracias por elegirnos!", "success")
    carritoCompras.length = 0
    localStorage.removeItem("carrito")
    setTimeout(() => retornarAhome(), 3500)
})

btnVolver.addEventListener("click", ()=> retornarAhome())