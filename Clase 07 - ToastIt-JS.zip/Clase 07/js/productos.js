// ENDPOINTS
// https://endpointdeproductos.com/v1/categorias

// https://endpointdeproductos.com/v1/productos

const carritoCompras = [
    { id: "36", imagen: "🍷", nombre: "Vino", precio: 1800, categoria: "Bebida" },
    { id: "32", imagen: "🧀", nombre: "Queso", precio: 450, categoria: "Comida" },
    { id: "29", imagen: "🍞", nombre: "Pan", precio: 200, categoria: "Comida" },
    { id: "31", imagen: "🍝", nombre: "Pasta", precio: 400, categoria: "Comida" },
    { id: "28", imagen: "🫒", nombre: "Aceitunas", precio: 360, categoria: "Verdura" },
    { id: "22", imagen: "🌶️", nombre: "Pimiento", precio: 450, categoria: "Verdura" },
    { id: "16", imagen: "🍋", nombre: "Limones", precio: 260, categoria: "Fruta" },
]

const productos = [
    { id: "1", imagen: "🍌", nombre: "Bananas", precio: 1220, categoria: "Fruta" },
    { id: "2", imagen: "🍎", nombre: "Manzana roja", precio: 1890, categoria: "Fruta" },
    { id: "3", imagen: "🥝", nombre: "Kiwis", precio: 760, categoria: "Fruta" },
    { id: "4", imagen: "🍈", nombre: "Melón", precio: 350, categoria: "Fruta" },
    { id: "5", imagen: "🍍", nombre: "Ananá", precio: 750, categoria: "Fruta" },
    { id: "6", imagen: "🍅", nombre: "Tomates", precio: 940, categoria: "Fruta" },
    { id: "7", imagen: "🍏", nombre: "Manzana verde", precio: 790, categoria: "Fruta" },
    { id: "8", imagen: "🍉", nombre: "Pomelo Rosado", precio: 1200, categoria: "Fruta" },
    { id: "9", imagen: "🍑", nombre: "Duraznos", precio: 710, categoria: "Fruta" },
    { id: "10", imagen: "🫐", nombre: "Arándanos", precio: 650, categoria: "Fruta" },
    { id: "11", imagen: "🥭", nombre: "Mango", precio: 290, categoria: "Fruta" },
    { id: "12", imagen: "🍇", nombre: "Uvas", precio: 700, categoria: "Fruta" },
    { id: "13", imagen: "🍐", nombre: "Peras", precio: 320, categoria: "Fruta" },
    { id: "14", imagen: "🍒", nombre: "Cerezas", precio: 1100, categoria: "Fruta" },
    { id: "15", imagen: "🍓", nombre: "Frutillas", precio: 600, categoria: "Fruta" },
    { id: "16", imagen: "🍋", nombre: "Limones", precio: 260, categoria: "Fruta" },
    { id: "17", imagen: "🍋‍🟩", nombre: "Lima", precio: 2260, categoria: "Fruta" },
    { id: "18", imagen: "🍉", nombre: "Sandía", precio: 1140, categoria: "Fruta" },
    { id: "19", imagen: "🥑", nombre: "Palta", precio: 850, categoria: "Fruta" },
    { id: "20", imagen: "🌽", nombre: "Maíz", precio: 220, categoria: "Verdura" },
    { id: "21", imagen: "🥒", nombre: "Pepino", precio: 190, categoria: "Verdura" },
    { id: "22", imagen: "🌶️", nombre: "Pimiento", precio: 450, categoria: "Verdura" },
    { id: "23", imagen: "🥬", nombre: "Lechuga", precio: 150, categoria: "Verdura" },
    { id: "24", imagen: "🫑", nombre: "Morrón verde", precio: 550, categoria: "Verdura" },
    { id: "25", imagen: "🧅", nombre: "Cebolla", precio: 130, categoria: "Verdura" },
    { id: "26", imagen: "🧄", nombre: "Ajo", precio: 100, categoria: "Verdura" },
    { id: "27", imagen: "🥔", nombre: "Papa", precio: 180, categoria: "Verdura" },
    { id: "28", imagen: "🫒", nombre: "Aceitunas", precio: 360, categoria: "Verdura" },
    { id: "29", imagen: "🍞", nombre: "Pan", precio: 200, categoria: "Comida" },
    { id: "30", imagen: "🥫", nombre: "Sopa enlatada", precio: 320, categoria: "Comida" },
    { id: "31", imagen: "🍝", nombre: "Pasta", precio: 400, categoria: "Comida" },
    { id: "32", imagen: "🧀", nombre: "Queso", precio: 450, categoria: "Comida" },
    { id: "33", imagen: "🍪", nombre: "Galletas", precio: 250, categoria: "Comida" },
    { id: "34", imagen: "🥤", nombre: "Refresco", precio: 150, categoria: "Bebida" },
    { id: "35", imagen: "🍺", nombre: "Cerveza", precio: 500, categoria: "Bebida" },
    { id: "36", imagen: "🍷", nombre: "Vino", precio: 1800, categoria: "Bebida" },
    { id: "37", imagen: "🧃", nombre: "Jugo", precio: 180, categoria: "Bebida" },
    { id: "38", imagen: "☕", nombre: "Café Espresso", precio: 7500, categoria: "Bebida" },
    { id: "39", imagen: "🐟", nombre: "Pescado", precio: 700, categoria: "Comida" },
    { id: "40", imagen: "🍖", nombre: "Carne", precio: 1200, categoria: "Comida" },
    { id: "41", imagen: "🍚", nombre: "Arroz", precio: 250, categoria: "Comida" },
    { id: "42", imagen: "🥚", nombre: "Huevos", precio: 180, categoria: "Comida" },
    { id: "43", imagen: "🍾", nombre: "Espumante", precio: 1100, categoria: "Bebida" },
    { id: "44", imagen: "🥦", nombre: "Brócoli", precio: 750, categoria: "Verdura" },
    { id: "45", imagen: "🍹", nombre: "Licores", precio: 9300, categoria: "Bebida" },
    { id: "46", imagen: "💧", nombre: "Agua purificada", precio: 1230, categoria: "Bebida" },
    { id: "47", imagen: "🥃", nombre: "Whisky añejo", precio: 11820, categoria: "Bebida" },
    { id: "48", imagen: "🍊", nombre: "Naranja", precio: 915, categoria: "Fruta" },
]

const productosStock = [
    { "id": "1", "imagen": "🍌", "nombre": "Bananas", "precio": 1220, "categoria": "Fruta", "stock": 43 },
    { "id": "2", "imagen": "🍎", "nombre": "Manzana roja", "precio": 1890, "categoria": "Fruta", "stock": 71 },
    { "id": "3", "imagen": "🥝", "nombre": "Kiwis", "precio": 760, "categoria": "Fruta", "stock": 65 },
    { "id": "4", "imagen": "🍈", "nombre": "Melón", "precio": 350, "categoria": "Fruta", "stock": 27 },
    { "id": "5", "imagen": "🍍", "nombre": "Ananá", "precio": 750, "categoria": "Fruta", "stock": 0 },
    { "id": "6", "imagen": "🍅", "nombre": "Tomates", "precio": 940, "categoria": "Fruta", "stock": 49 },
    { "id": "7", "imagen": "🍏", "nombre": "Manzana verde", "precio": 790, "categoria": "Fruta", "stock": 66 },
    { "id": "8", "imagen": "🍉", "nombre": "Pomelo Rosado", "precio": 1200, "categoria": "Fruta", "stock": 52 },
    { "id": "9", "imagen": "🍑", "nombre": "Duraznos", "precio": 710, "categoria": "Fruta", "stock": 38 },
    { "id": "10", "imagen": "🫐", "nombre": "Arándanos", "precio": 650, "categoria": "Fruta", "stock": 41 },
    { "id": "11", "imagen": "🥭", "nombre": "Mango", "precio": 290, "categoria": "Fruta", "stock": 0 },
    { "id": "12", "imagen": "🍇", "nombre": "Uvas", "precio": 700, "categoria": "Fruta", "stock": 35 },
    { "id": "13", "imagen": "🍐", "nombre": "Peras", "precio": 320, "categoria": "Fruta", "stock": 29 },
    { "id": "14", "imagen": "🍒", "nombre": "Cerezas", "precio": 1100, "categoria": "Fruta", "stock": 61 },
    { "id": "15", "imagen": "🍓", "nombre": "Frutillas", "precio": 600, "categoria": "Fruta", "stock": 45 },
    { "id": "16", "imagen": "🍋", "nombre": "Limones", "precio": 260, "categoria": "Fruta", "stock": 0 },
    { "id": "17", "imagen": "🍋‍🟩", "nombre": "Lima", "precio": 2260, "categoria": "Fruta", "stock": 33 },
    { "id": "18", "imagen": "🍉", "nombre": "Sandía", "precio": 1140, "categoria": "Fruta", "stock": 47 }
]

// function saludar(texto) {
//     console.log(texto)
// }

// texto = "Hola, mundo"
// salida = alert, prompt, confirm, console.log, console.warn, console.error, console.info
// function saludar(texto, salida) {
//     salida(texto)
// }

function recorrerArray() {
    productos.forEach((producto) => {
        console.log(producto)
    })

    // for (let producto of productos) {
    //     if (producto.id === "15") {
    //         break 
    //     } else {
    //         console.log(producto)
    //     }
    // }
}

function encontrarProducto() {
    const productoEncontrado = productos.find((producto) => producto.nombre === "Brócoli")
    if (productoEncontrado !== undefined) {
        console.log(productoEncontrado)
    } else {
        console.warn("No se encontró producto con ese valor.")
    }
}

function filtrarProductosPorCat() {
    const productosFiltrados = productos.filter((prod) => prod.categoria === "Verdura")
    console.table(productosFiltrados)
}

function filtrarPorCategoriaYprecio() {
    const productosFiltrados = productos.filter((prod) => prod.categoria === "Bebida" && prod.precio > 4000)
    console.table(productosFiltrados)
}

function filtrarPorPrecio() {
    const productosFiltrados = productos.filter((prod) => prod.precio > 1000)
    console.table(productosFiltrados)
}

function filtrarPorRangoDePrecio() {
    const productosFiltrados = productos.filter((prod) => prod.precio > 1000 && prod.precio < 2600)
    console.table(productosFiltrados)
}

function validarStockDeProductos() {
    const resultado = productosStock.some((prod) => prod.stock === 0)
    // return resultado 

    if (resultado) {
        console.warn("Hay productos con Stock en cero (0).")
    } else {
        console.log("Todos los productos tienen stock óptimo.")
    }
}

function validarPrecioDeProductos() {
    const resultado = productosStock.some((prod) => prod.precio <= 0)

    if (resultado) {
        console.warn("Hay productos con precio en cero (0).")
    } else {
        console.log("Todos los productos tienen el precio correcto.")
    }
}

function validarQueTodosLosProductosTenganPrecio() {
    const resultado = productosStock.every((prod) => prod.precio > 0)

    console.log(resultado)
}

function mapearInfoDeProductos() {
    const productosSinStock = productosStock.map((prod) => {
        return {
            codigo: prod.id,
            nombre: prod.nombre.toUpperCase(),
            imagen: prod.imagen,
            precio: prod.precio,
            categoria: prod.categoria
            // eliminamos columna Stock
        }
    })

    console.table(productosSinStock)
}

function mapearPrecioDeProductos() {
    const productosSinStock = productosStock.map((prod) => {
        return {
            codigo: prod.id,
            nombre: prod.nombre.toUpperCase(),
            imagen: prod.imagen,
            precioLista: prod.precio,
            precio10off: parseFloat((prod.precio * 0.9).toFixed(2)),
            precio7on: parseFloat((prod.precio * 1.07).toFixed(2)),
            categoria: prod.categoria
        }
    })

    console.table(productosSinStock)
}

function generarCategoriasUnicas() {
    // .map() + Set() (set = conjuntos)
    const mapearCategorias = productos.map((prod) => prod.categoria)
    console.table(mapearCategorias)
    
    const arrayCategoriasUnicas = [...new Set(mapearCategorias)]

    return arrayCategoriasUnicas
}


function ordenarProductosPorNombre() {
    let i = 0

    productos.sort((a, b) => {
        i++

        if (a.nombre > b.nombre) {
            return 1
        }

        if (a.nombre < b.nombre) {
            return -1
        }

        return 0
    })

    console.log("Iteraciones:", i)
    console.table(productos)
}

function ordenarProductosPorPrecio() {
    let i = 0

    productos.sort((a, b) => {
        i++

        if (a.precio > b.precio) {
            return 1
        }
        if (a.precio < b.precio) {
            return -1
        }
        return 0
    })

    console.log("Iteraciones:", i)
    console.table(productos)
}

function ordenarProductosPorNombreDesc() {
    let i = 0

    productos.sort((a, b) => {
        i++
        if (a.nombre < b.nombre) return 1
        if (a.nombre > b.nombre) return -1
        return 0
    })

    console.log("Iteraciones:", i)
    console.table(productos)
}


const paisesAmericaDelSur = [
  "Argentina",
  "Bolivia",
  "Brasil",
  "Chile",
  "Colombia",
  "Ecuador",
  "Guyana",
  "Paraguay",
  "Perú",
  "Surinam",
  "Uruguay",
  "Venezuela",
  "Guayana Francesa" // Territorio de ultramar francés
];

const paisesAmericaDelNorte = [
  "Canadá",
  "Estados Unidos",
  "México",
  "Guatemala",
  "Belice",
  "El Salvador",
  "Honduras",
  "Nicaragua",
  "Costa Rica",
  "Panamá",
  "Cuba",
  "República Dominicana",
  "Haití",
  "Jamaica",
  "Bahamas",
  "Barbados",
  "Trinidad y Tobago",
  "Granada",
  "San Vicente y las Granadinas",
  "Santa Lucía",
  "Antigua y Barbuda",
  "Dominica",
  "San Cristóbal y Nieves"
];

const paisesDeAmerica = ["Isla de Pascua", paisesAmericaDelSur, paisesAmericaDelNorte]

function aplanarArrayPaises() {
    console.table(paisesDeAmerica.flat(1))
}

function agruparProductosPorCategoria() {
    const productosAgrupados = Object.groupBy(productos, (prod)=> prod.categoria )

    for (let categoria in productosAgrupados) {
        console.log(categoria)
        console.table(productosAgrupados[categoria])
    }
}

function calcularTotalCarrito() {
    return carritoCompras.reduce((acc, prod)=> acc + prod.precio, 0 )
}

function calcularTotalCarritoOld() {
    let total = 0

    carritoCompras.forEach((prod)=> {
        total = total + prod.precio
    })

    return total
}